package za.ac.tut.model.bl;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateful;

/**
 *
 * @author MemaniV
 */
@Stateful
public class ListSB implements ListSBLocal {
    private List<Integer> numbers = new ArrayList<>();
    
    @Override
    public void add(Integer num) {
        numbers.add(num);
    }
    @Override
    public Integer getSize() {
        return numbers.size();
    }
    @Override
    public List<Integer> getList() {
        return numbers;
    }   
}

